# Archipelago
CSCI4176 Group3
Minimum Functionality
At a minimum we shall deliver:
A tiled map with three segments, one for each player and a neutral zone in the middle
One (1) resource: money
Three (3) units: one (1) for building, one (1) for gathering resources, and one (1) for defending 
One (1) offensive action to capture an enemy tile
A single resource collection point in the neutral zone
Two (2) buildings, one(1) which can defend a tile and one (1) that can increase the income from a tile
One (1) trap a player can use defensively without the other player being aware of it
A stand in A.I. which acts as an opponent but performs no actions 
Basic Sound effects

Expected Functionality 
In addition to minimum functionality we expect to deliver:
Multiple resources with money being the primary resource and others being used to allow access to higher tier units
Multiple tiers of units that function as better versions of the basic units but require higher tier resources
Multiple resource collection points around the map of varied value.
Multiple offensive actions for the player to use against their opponent
Multiple traps a player can use defensively without the other player being aware of it

Bonus Expectation
Lobby based network multiplayer (no matchmaking or ranking)
Random map generation
Highly polished Visuals  
Team or Free-For-All game mode
More units, maps, tools, features, etc.
Player Progress Tracking
Local Multiplayer (2 Players 1 screen)
