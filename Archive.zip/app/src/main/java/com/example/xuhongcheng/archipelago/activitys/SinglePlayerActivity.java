package com.example.xuhongcheng.archipelago.activitys;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.xuhongcheng.archipelago.myapplication.R;


public class SinglePlayerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_player);
    }
}
